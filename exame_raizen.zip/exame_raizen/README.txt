Para o desenvolvimento do teste, foi utilizado Anaconda e Jupyter Notebook.

Os script de ETL estão dentro da pasta Scripts, sendo:

O script "generate_raw_data" ao ser executado chama os outros dois programas "pivot1" e "pivot3".

Após a execução, os dados tratados são salvos no diretório "output".

Algumas pastas auxiliares são criadas.

