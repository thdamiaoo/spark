# -*- coding: utf-8 -*-

#-----------------------------------------------------------------------------------------------------------
#-- ASSUNTO       : Extração dados pivot table fuel by UF                                                 --
#-- PERIODICIDADE : Sob demanda                                                                           --
#-- AUTOR         : Thiago Damião de Freitas                                                              --
#--                                                                                                       --
#-- DESCRICAO     : Script para extração dos dados referentes a pivot table 1 do arquivo vendas-combustí- --
#--                 -veis-m3.xls                                                                          --
#--                                                                                                       --
#-- TABELA FINAL  : fuel_by_uf                                                                            --
#-- DT ALTERACAO  : 17/09/2021                                                                            --
#-----------------------------------------------------------------------------------------------------------

import win32com.client as win32
import os, sys
import zipfile
import xml.etree.ElementTree as et
import pandas as pd
import logging
from datetime import datetime

global config
global query
global project
global db
global area
global project_dir
global log_dir
global df_query_exp

def conv_to_xlsx(): #convert xls format to xlsx function
    try:
        file_name = 'exame_raizen/data/vendas-combustiveis-m3.xls'
        excel = win32.gencache.EnsureDispatch('Excel.Application')
        wb = excel.Workbooks.Open(file_name)     
        wb.SaveAs(file_name+"x", FileFormat = 51)
        wb.Close()                               
        excel.Application.Quit()
        print('Arquivo convertido de xls para xlsx.')
    except:
        print('Falha na conversão de formato')
        return None

def rename_xlsx_to_zip(): #altera a extenção do arquivo de xlsx para zip
    try:
        path = 'exame_raizen/data/'
        dir = os.listdir(path)
        for file in dir:
            if file == 'vendas-combustiveis-m3.xlsx':
                os.rename('exame_raizen/data/vendas-combustiveis-m3.xlsx', 'exame_raizen/data/vendas-combustiveis-m3.zip')
                print('A extensão do arquivo', file, 'foi substituida para (.csv)!!!')
    except:
        os.remove('exame_raizen/data/vendas-combustiveis-m3.xlsx')
        print('Arquivo', file, 'já existe. Removido!')
        return None

def unzip_file(): #cria diretório unzip e descompacta zip
    dir = 'exame_raizen/'+'unzip'
    if not os.path.exists(dir):
        os.makedirs(dir)
        with zipfile.ZipFile('exame_raizen/data/vendas-combustiveis-m3.zip', 'r') as zip_ref:
            zip_ref.extractall('exame_raizen/unzip/')

def mkdir_output(): #cria diretório para guardar dados tratados
    dir = 'exame_raizen/'+'output'
    if not os.path.exists(dir):
        os.makedirs(dir)           

def delete_zip_file(): #remove arquivo zip
    path = 'exame_raizen/data/'
    dir = os.listdir(path)
    for file in dir:
        if file == 'vendas-combustiveis-m3.zip':
            os.remove('exame_raizen/data/vendas-combustiveis-m3.zip')
            print('O arquivo', file, 'foi removido do diretório:', path)
        else:
            pass            

def dir_log(): # diretório para guardar arquivo de log
    dir_log = 'exame_raizen/'+'log'
    if not os.path.exists(dir_log):
        os.makedirs(dir_log)

conv_to_xlsx()
rename_xlsx_to_zip()
unzip_file()
delete_zip_file()
mkdir_output()

print('\nIniciando interpretação dos xml(s) com as informações da pivot table...')

# recupera dicionario e colunas da pivot definições
definitions = 'exame_raizen/unzip/xl/pivotCache/pivotCacheDefinition1.xml'
defdict = {}
columnas = []
e = et.parse(definitions).getroot()
for fields in e.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}cacheFields'):
  for cidx, field in enumerate(fields.getchildren()):
      columna = field.attrib.get('name')
      defdict[cidx] = []
      columnas.append(columna)
      for value in field.getchildren()[0].getchildren():
          tagname = value.tag
          defdict[cidx].append(value.attrib.get('v', 0))

# recupera os dados da pivot records
dfdata = [] #cria dataframe
bdata = 'exame_raizen/unzip/xl/pivotCache/pivotCacheRecords1.xml'
for event, elem in et.iterparse(bdata, events=('start', 'end')):
    if elem.tag == '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}r' and event == 'start':
       tmpdata = []
       for cidx, valueobj in enumerate(elem.getchildren()):
           tagname = valueobj.tag
           vattrib = valueobj.attrib.get('v')
           rdata = vattrib
           if tagname == '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}x': #primeira tag do xml
                try:
                  rdata = defdict[cidx][int(vattrib)]
                except:
                  logging.error('Não deve ocorrer index cidx = {} vattrib = {} defaultidcts = {} tmpdata for the time = {} xml raw {}'.format(
                                                                                                                                       cidx, vattrib, defdict, tmpdata,
                                                                                                                                       et.tostring(list, encoding='utf8', method='xml')
                                                                                                                                       ))
           tmpdata.append(rdata)
       if tmpdata:
           dfdata.append(tmpdata)
       elem.clear()

fuel_by_uf = pd.DataFrame(dfdata) #cria dataframe com os dados de dfdata
fuel_by_uf.columns = ['product', 'year', 'region', 'uf', 'unit', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', 'total'] #coloca nome nas colunas
fuel_by_uf = fuel_by_uf.drop('total', 1) # exclui coluna "total"

for column in ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12']: #formata meses
    fuel_by_uf[column] = round(fuel_by_uf[column].astype(float),2)

df = fuel_by_uf # copia dos dados

df = df.melt(id_vars=['product', 'year','region', 'uf', 'unit'], var_name=['month'], value_name='volume') # pivot invertida

new_col = df['year'] + '-' + df['month'] # monta coluna com ano + mês
df['year_month'] = new_col  # insere coluna no df
df.groupby(['product', 'year', 'region', 'uf', 'unit', 'month', 'year_month']).sum() # sumariza volume agregado
df = df.drop(['year', 'region', 'month'], 1) # exclui colunas desnecessárias
data_atual = datetime.now() # data atual
df['created_at'] = data_atual # insere nova coluna com conteudo de data_atual
df = df[['year_month', 'uf', 'product', 'unit', 'volume', 'created_at']] # organiza colunas conforme schema definido
df.to_csv('exame_raizen/output/fuel_by_uf.csv', sep=';', header='true', index_label='id', encoding='Latin-1') #salva dados

if __name__ == '__main__':
    print('Dados da pivot table "fuel by UF" foram extraídos, tratados e salvos conforme schema!')
