# -*- coding: utf-8 -*-

#-----------------------------------------------------------------------------------------------------------
#-- ASSUNTO       : Roda rotinas para geração das tabelas raw da pivot 1 e 3                              --
#-- PERIODICIDADE : Sob demanda                                                                           --
#-- AUTOR         : Thiago Damião de Freitas                                                              --
#--                                                                                                       --
#-- DESCRICAO     : Script para execução quanto a geração dos dados extráidos das pivot 1 e 3 do arquivo  --
#--                 vendas_combustiveis-m3.xls                                                            --
#--                                                                                                       --
#-- TABELA FINAL  : --                                                                                    --
#-- DT ALTERACAO  : 17/09/2021                                                                            --
#-----------------------------------------------------------------------------------------------------------

import subprocess

subprocess.call('exame_raizen/scripts/pivot1.py', shell=True)
subprocess.call('exame_raizen/scripts/pivot3.py', shell=True)
print('Dados da pivot 1 e 3 foram tratados e salvos no diretório: /exame_raizen/output')
